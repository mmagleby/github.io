Rendermod v2

I've used max188's Render Mod Script and ASHE to modify the planes.dat files for the following add-ons campaigns:

Poland 1939 		by Emil
France 1940 		by Charles Gunst modified by DOM
France 1940 RAF Edition by Charles Gunst modified by DOM and BlueBaron
Mediterranean 1941 A/B 	by Emil
Caucasus 1942 		by Emil
Tunisian 1942 		by Emil

Quote from max188's Render Mod Script Readme file:
"This script will modify the distance rendering model values for each plane slot in a given planes.dat file.  The values are set to 200% of the original values with the exception of Dot, which is set to 150%.  The Line value is also capped at 350000, which appears to be close to the maximum for this value."
End quote.

I've only run the script after selecting the appropriate planes for each campaign in ECA Panel, so the credit should go to Charles Gunst for his ECA Panel and to max188 for his Render script.

The following aircraft have been selected for the campaigns:

Poland 1939
Polish aircraft selected in ECA Panel as follows:

Hurricane:	PZL P.11c
Spitfire I:	PZL P.24a
Mosquito:	PZL P.37b
P 51 B:		PZL P.23b
Bf 109 E:	Bf-109 E1
Bf 109 G:	Hs-123 A1
Bf 110 C:	Bf-110 C4
Ju 87 B:	Ju-87 B2
Ju 88 A:	Do-17 Z2
He 111 H:	He-111 H2

France 1940
French aircraft selected in ECA Panel and individually as follows:

Hurricane:	Morane MS.406
Spitfire I:	Dewoitine D.520
Spitfire IX:	Caudron C.714
Spitfire XIV:	Bloch MB-155
Typhoon:	Curtiss Hawk 75A
Tempest:	Bloch MB-152
Mosquito:	Potez 631
P 38 J:		Fokker G-1 Mercury
P 51 B:         Fairey Batle MkI
B 26:		Amiot 354 B4
Fw 190 A:	Macchi C.200
Ju 88 A:	Do-17 Z2
Bf 109 E:	Bf-109 E3
Bf 110 C:	Bf-110 C4
Ju 87 B:	Ju-87 B2
He 111 H:	He-111 H2

France 1940 RAF Edition
French aircraft selected in ECA Panel and individually as follows:

Hurricane 	Hurricane I
Spitfire I	Spitfire I
Spitfire IX 	Gladiator I
Spitfire XIV 	Bloch MB-155
Typhoon 	Defiant I
Tempest 	Skua II
Mosquito 	Wellington I

P 51 B 		Fairey Battle I
P 51 D 		Fokker D-XXI
P 38 H 		Beaufighter IF 
P 38 J 		Fokker G1 Mercury
P 47 C 		F6F-3 (Martlet)
P 47 D 		Hurricane I
B 26 B 		Blenheim I

Bf 109 K  	Ju-87 B2
Fw 190 A8  	Macchi C.200
Fw 190 D9  	Fiat CR-42
Ju 88 A:	Do-17 Z2
Bf 109 E:	Bf-109 E3
Bf 110 C:	Bf-110 C4
Ju 87 B:	Ju-87 B2
He 111 H:	He-111 H2

Mediterranean 1941
North African aircraft selected in ECA Panel and individually as follows:

Hurricane:	Hurricane IIc
Spitfire I:	Spitfire IIb
Spitfire IX:	Spitfire Vb
Typhoon:	Tomahawk Ia
Tempest:	Kittyhawk II
Mosquito:	Beaufighter IF
P 47 C:		F4F-3 Wildcat
B 26 B:		Blenheim I 
Bf 109 E:	Bf-109 E8
Bf 109 G:	Bf-109 F4
Bf 110 C:	Bf-110 F1
Me 410 A:	Me-210 A1
Ju 87 B:	Ju-87 D7
Ju 88 A:	Ju-88 A4

Caucasus 1942
Russian aircraft selected in ECA Panel and individually as follows:

Hurricane:	MiG-3
Spitfire I:	LaGG-3
Spitfire IX:	Yak-9D
Typhoon:	La-5
Tempest:	Kittyhawk II
Mosquito:	Pe-2
P 47 C:		Su-2 
P 47 D:		Il-2 
B 26 B:		Il-4
Bf 109 E:	Bf-109 F2
Bf 109 G:	Bf-109 G2
Bf 110 C:	Bf-110 F1
Ju 87 B:	Ju-87 D7
Ju 88 A:	Ju-88 A4
He 111 H:	He-111 H2

Tunisian 1942
North African aircraft selected in ECA Panel and individually as follows:

Hurricane:	Hurricane IIc
Spitfire I:	P-39 Q Airacobra 
Spitfire IX:	Spitfire Vb
Tempest:	Kittyhawk II
Mosquito:	Wellinton Mk I
P 51 B:		P-40 E 
P 38 H:		P-38 H
P 47 C:		F4F-4 Wildcat
P 47 D:		Hurricane I
B 26:		B-25 Mitchell
Bf 109 E:	Macchi C.202
Bf 109 G:	Bf-109 F4 
Bf 110 C:	Bf-110 F1
Me 410 A:	Me-210 A1
FW 190 A:	Fw-190 A4
Ju 87 B:	Ju-87 D7
Ju 88 A:	Ju-88 A4
He 111 H:	He-111 H2


Per "vonOben" Rasmusson
2001-08-11

per.eslov@spray.se
