EAW Plane Rendering Mod


This modified planes.dat file causes EAW to use higher quaility plane rendering models for longer distances. This makes it easier to identify the type and orientation of the plane at further distances (See render2.jpg). It also increases the distance that planes are visible as dots.


How it works:

Planes are rendered in 5 stages in EAW depending on their distance (See render1.jpg for examples).

1) Full quality textures and 3d models
2) Simplified textures and 3d models
3) Flat textures
4) Lines
5) Dots

The distance that each rendering model is used was doubled from the defaults. Ie., the full quality model will be used up to 200 feet instead of the usual 100 feet. The distance that the plane is visible as a dot was increased by 50%. Each type of plane uses different baseline values.

The logic behind this is that the original values were optimized for the game's default 640x480 resolution. Now, with 1280x960 and similar resolutions available, we have twice the resolution to work with. So, we can extend the rendering models out twice as far to capitalize on these higher resolutions. Of course, if you are not running at a resolution higher than the 640x480 default, you probably won't benefit much from this.

The change in maximum visibility distance as a dot equates to about 21 miles for the largest bomber to about 12 miles for a fighter (as near as I can tell).




INSTRUCTIONS 

1) BACKUP any existing planes.dat file in your EAW directory.

2) IMPORTANT: Determine which planes.dat file in this package you will need to use. Many add-ons make changes to the planes.dat file so you will need to use the correct one to maintain these changes. Files are provided for the following add-ons:

    ECAO1.4

    ECA1.4 (excluding ECA Panel)

    Emil's Bob (includes 6/28 update) 

    1942 ETO    

    Pacific Tide 2.0 

    Midway 

    Default EAW (All versions)
  
If you are using any other campaign that has its own planes.dat-- well, you may want to try the ECA1.4 file, but I have not tested with anything other than those listed above. Results may be unpredictable. 

In addition, since ECAPanel rewrites the planes.dat file, it will not work with this utility.

3) Locate the planes.dat file in the appropriate directory in this package and copy it to your EAW directory.

4) That's it. Now just run EAW as normal.




Notes:

1) Although I did not notice any frame rate hit on my system (PIII 900, Geforce2 GTS), you may notice a performance degradation depending on your hardware setup.

2) You will not want to use this for online play, as planes.dat is one of the files that EAW checks for consistancy between players. However, if all the players are using the same file, you should be okay.

3) To remove this mod, delete the new planes.dat file from your EAW directory and copy over the one you backed up earlier.

3) Thanks to Charles Gunst for documenting these hex values in his EAW Editing Notes. Charles and many others have put forth a huge effort in making the game what it is today.



max188
http://www.xmission.com/~mmagleby/eaw


6/26/01 -- EAW Plane Rendering Mod
7/10/01 -- Added support for additional planes.dat files
7/16/01 -- Capped line rendering distace to prevent bomber dropouts
8/19/01 -- Added planesLF.dat for low-fuel BoB 




 
