SkyManager_2001 -- 07/11/2001

By Spit9 (a.k.a. J. L. Salvadoretti) 


Many thanks to:
- Pretzel and Migge, for their great work  creating their fabulous skies;
- Drift_Factor, for the idea;
- Mane-Raptor, for the tips on VB code;
- MrMark, for suggesting and testing the present version, and for his new skies;
- All you that contributed with your suggestions, experience and patience! 

*** CHANGES FROM v. 1.3:
- Unlimited number of different "skies" (see "ADDING NEW SKIES" below);
- Reduced size;
- New and simpler GUI.

*** CHANGES FROM v.1.2:
- Thumbnail pictures and labels removed from the .EXE file; 
- Transparency files can now be used;
- Users can now create and use your own "skies"! (see "CHANGING AVALIABLE SKIES" below)

*** CHANGES FROM v.1.1 & v.1.1a:
- Automatic detection of EAW folder - no more troubles with paths in SM.INI!
- Screen size automatic adjust to any resolution.
- Two "new" skies: 'Scattered & Horizon' and 'Bigger Clouds'. 'Scatt & Horizon' is a mix between the Pretzel's 'Scattered Clouds'(unmodified) and a new horizon with clouds. 'Bigger Clouds' is a new sky with (as the name says...) sparse thicker clouds with darker bottoms, resembling pre-cumulus. They give a feeling of being more near of the a/c, I think, even you still could not reaching them.

*** CHANGES FROM v.1.0:
- New weather files from Migge & Pretzel - better colors and TNT-compatibility! Pretzel's "fluffy   clouds" are now within the "sunny" sets of files.
- Corrected problem unzipping subfolders.
- Added option to allow user to save selected sky as default and/or restore a previous default.
- Added Migge's Winter Sky.
- Reduced .EXE size.


*** WHAT IS IT?
SkyManager_2001 is the last version of an EAW add-on intended to allow the user to select what kind of weather he wants for a "Quick Start" or "Single Mission". It will also work in "Carreer" mode, provided that the change of seasons (or others add-ons used) don't change the selected weather files. 
SkyManager_2001 uses sets of weather files, allowing to choose among a now unlimited number of different kinds of weather. A last option is "RANDOM", that will make the program to select randomly one kind of weather. 
Now you can have sunny winter days as well as summer storms...

*** HOW IT WORKS?
Very simple - SkyManager_2001 first looks in your EAW folder for any weather files and delete them; then it copies to that folder the files corresponding to the desired weather. These files are stored in subfolders named SM0 to SM**, under \SM_2001. When you select a kind of weather by pressing "Load to EAW", you can also set this as your own default skies, and restore then when you want. You can also restore the default EAW weather files at any moment.

In order to keep the pack as small as possible, the SM_2001.ZIP file contains only the main files and folders. Some required VB5 .DLLs can be easily obtained over the Internet - if you receive a message about a missing .DLL, do a search for it and copy it to your \Windows\System folder. If possible, will be releasing a second pack with these .DLLs. 


*** SETUP:
Due to the zipping problems, there's a bit of manual work involved here, but not too much...

1) INSTALLATION:
You don't need a previous version of SkyManager, but if you have one, don't delete it now! You can re-use your existing folders and save a lot of time and work!

-Unzip the files contained in SM_2001.ZIP to a temporary  directory. This ZIP contains the main files and folders needed. Be sure the box "Use Folder Names" or similar in your 'zip' program is checked. You should have now 11 zipped folders (from SM0.ZIP to SM10.ZIP), the executable (SM_2001.EXE), and this file (README.TXT), plus a screenshot of the program's screen (you can delete this later). 

- Create a folder named "SM_2001" under your EAW  folder (the  name  MUST be this!); copy all  the main files (not the SM*.ZIP ones) from the temporary  directory to this folder.

- Under this folder (\SM_2001), create eleven subfolders named SM0, SM1.....SM10; create also a subfolder named SMDef. If you have the 1.3 version, just copy all your subfolders here and skip the next step. 

- Unzip each zipped folder (SM*.ZIP) to the correspondent subfolder you created - SM0.ZIP to \SM_2001\SM0, and so on; let SMDef empty.

- Sorry... all this is necessary because the 'zip' process doesn't accept to compress different folders that have files with same names, so I must zip every subfolder before all program could be zipped itself.  

- Create (or update) a shortcut to your desktop for SM_2001.exe, if  you  don't use  EAWStab;

- If  you  use it,  then  open it and select "Configure"/"External Applications"/"Add". Follow the instructions, and EAWStab will create a new external application for SkyManager_2001. If you want to replace some of the default applications (some you don't have) with SM_2001, you can select "Configure"/ "External Applications"/"Delete" to remove it before adding SkyManager_2001. Or, if you want to do it manually, you can edit the [External] section of EAWSTAB.INI.

- If you are using SkinsAndMore, sorry, I can't help you, but then you don't need this program: SkinsAndMore can manage weather files itself - check it!

- It's all.

*** HOW TO USE: 

- Without STAB:  Click  the shortcut on desktop to launch SkyManager_2001;
		 Use the "back" and "next" arrows to browse your available "skies"; 
		 Select the one you want by clicking  in the picture;
		 Click "LOAD TO EAW";
		 Click "EXIT";
		 Launch EAW.

- With STAB:     Launch Stab;
		 From  the  External Applications menu, select "SM_2001";
		 Use the "back" and "next" arrows to browse your available "skies";
		 Select the one you want by clicking  in the picture;
		 Click "LOAD TO EAW";
		 Click "EXIT";
		 Use STAB to launch EAW.

If you  choose  "Random" (the 'question' pic in any screen), then SkyManager_2001 will sort the weather by itself among all you have installed (not just the 10 presently in the screen); you  can get a winter sky or fog even in Pacific! (but I think  it can add an extra thrill...)
If you have any weather files in the Terrain folders, be sure to remove them (or change terrains BEFORE launching SkyManager_2001) or it will have no effect.

-DEfAULTS:
-To save a selected kind of weather as your own default, just click the button "Save As My Default" after you clicked in "OK". These files will be copyed to the "SMDef" subfolder.

-To restore your last default, launch SkyManager_2001 and press the button "Load My Default", then "EXIT". Launch EAW again.

-To restore the original EAW sky, just launch SkyManager_2001 and press the button "Load EAW Default", then "EXIT". Launch EAW again.


*** CHANGING AVALIABLE SKIES:
SkyManager_2001 has a default preset of 11 different wheater patterns, or 'skies', from Migge, Pretzel and others. In this version, however, you can replace any of them by a new one, if you have the correct set of files for it. 
To do this: 

- Select the 'SM**' folder corresponding to the sky you want to replace;
- Delete all .TER files in it;
- Copy to this folder the new set of wheater files you want to use;
- Replace the 'SM**.BMP' file for a new one showing your new sky (must be a 200x130 pixels, 256 colors bitmap);
- Edit the 'SM**.TXT'file to change the label for this new sky and save it.
- Launch SkyManager_2001 and check if the changes are correct. 

*** ADDING NEW SKIES:
- First, obtain the set of *.TER files corresponding to the new weather;
- Create a new SM** folder under \SM_2001, and copy the files to it;
- Be sure the ending number(**) is the next after the last you already have (if your last SM folder is SM10, the new one must be SM11);
- If you have a pic of the new sky, edit it (if necessary) to a 256 colors, 200 x 130 bitmap;
- copy the edited pic to the new folder and rename it as SM**.BMP;
- create a .TXT file (or edit a existing one) with just one line containing the name or a short description of this sky - preferably less than 50 characters; name it SM**.TXT and put it in the new folder. 


Hope you enjoy it!

*** POSSIBLE TROUBLE:
If you receive a message of "Incorrect installation", it means that SkyManager_2001 is not installed under the EAW folder as it needs to be. Please re-check your install.


*** FEEDBACK: 
Any comments, sugestions, or criticism will be welcome. You can contact me at the SimHQ EAW Forum, or at spit9@terra.com.br. Please give me your opinion! 


*** DISTRIBUTION:
SkyManager was conceived as FREEWARE. If you like it, you can use and distribute it freely, provided no  modifications are made to the program or any of its files, including this README, and no fees are claimed. And, of course, a little bit of credit will be appreciated... ;-)


*** THE TRADITIONAL DISCLAIMER: 
SkyManager, as any other EAW add-on, is not suported by Microprose, Hasbro or don't know who (oh, well, EAW isn't too...). I'm not responsible for crashes, malfunctioning or any consequences of its use; but as SkyManager does not make any permanent changes to EAW, it will not ruin it in any way. In some systems, maybe other .DLLs can be necessary; I had not chance to test it.
EAW is a registred trademark of Microprose, Inc. (or Hasbro, etc...)
WINDOWS is a registered trademark of Microsoft Co.

******************************





