Winter EAW Airfields

This is a set of winter airfields for EAW.  It replaces the default airfields and runways.  It was created to match the look of the Hi-res Winter EAW terrain, but can be used with any winter terrain set.

The airfields were created using Paint Shop Pro 7 and picpac.  The default airfields (extracted and converted to pcx files by Moggy) were used as a base reference.  These airfields should be compatible with both TNT and 3DFX cards.  I hope you like them!
  


INSTRUCTIONS 

1) Unzip all the files to a directory.

2) Copy the *.tpc files to your EAW directory.

3) You're Done!  Run the game and enjoy the new airfields!



Notes:

1) If you use a terrain management program like STAB or Skins-n-More, you should copy the *.tpc files  to the appropriate directory instead of the EAW directory.  Check the program's instructions on how to handle airfield files.

2) I left out the pcx files to make the package smaller, but I have no problem providing them to anyone who wants to look at, modify, or do whatever to them.  I follow the simhq forum if you want to post a request there.

max188
http://www.xmission.com/~mmagleby/eaw

Rev 1 - 5/16/01 - Winter EAW Airfields
