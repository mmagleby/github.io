Hi-Res Hard Winter EAW Terrain

This terrain set is a hard winter version based on the original EAW terrain.  It uses the larger 256x256 terrain tiles in place of the 128x128 tiles, providing higher detail than was originally available in the game.

This terrain was created using picpac and the supplied standard EAW terrain tiles.  All modifications were done using Paint Shop Pro 7.  The goal of this terrain was to provide a very cold winter look with heavy snow-covered conditions. 



INSTRUCTIONS 

1) Unzip all the files to a directory.

2) Double-click on the make_bn.bat file to create the cooresponding bn*.ter files.

3) Copy the *.ter files to your EAW directory (there should be 118 of them).

4) You're Done!  Run the game and enjoy the winter scenery!



Notes:

1) If you use a terrain management program like STAB or Skins-n-More, you should copy the *.ter files  to the appropriate terrain directory instead of the EAW directory.

2) I recommend using winter buildings, trees, etc. with this terrain for full effect.  Check Sandbagger's site at http://sandbagger.freeyellow.com/index.html for available winter add-ons.

3) I left out the pcx files to make the package smaller, but I have no problem providing them to anyone who wants to look at, modify, or do whatever to them.  I follow the simhq forum if you want to post a request there.


max188
http://www.xmission.com/~mmagleby/eaw

Rev 1 - 8/19/01 - Hi-res Hard Winter EAW Terrain
