Render Mod Script

This is very useful if you have a custom planes.dat file that you 
wish to modify with the updated distance rendering model.  For
example, you can set up ECAPanel as desired and then modify the
resulting planes.dat file.

This script will modify the distance rendering model values for 
each plane slot in a given planes.dat file.  The values are set
to 200% of the original values with the exception of Dot, which is
set to 150%.  The Line value is also capped at 350000, which appears
to be close to the maximum for this value.

This script is written to be run by ASHE.  You can get the runtime
version of this program from 
http://www.grandriversoftware.com/download/index.shtml
Install ASHE RT and then open this script and run it.  When you run 
the script, it will prompt for the location of the planes.dat file
and make the cooresponding modifications.  It can be run against
any planes.dat file.

Please download the Distance Rendering Mod (rendermod.zip) for more
details on this mod, including several pre-built planes.dat files.
You only need to use this script if you wish to modify a planes.dat
that is not included as one of the pre-built files.

max188
7/14/01
http://www.xmission.com/~mmagleby/eaw