Hi-res Winter Terrain for Third Wire's First Eagles

This is a hi-res winter terrain set for First Eagles.  It is a winterized version of the hi-res summer terrain, and utilizes 512x512 tiles.  Also included are buildings and trees to match the winter landscape.





INSTRUCTIONS


OPTION 1 - Replace the default terrain

1) Back up your existing ..\ThirdWire\WWI\Terrain\wwwiVerdun directory.

2) Unzip the contents of this zip file into the existing ..\ThirdWire\WWI\Terrain\wwiVerdun directory.  You will see 95 new .bmp files and 23 new .tga files in the directory.

3) That's it, you're done.  Run the game and enjoy the terrain!

4) If you want to go back to the default terrain, just delete the new .bmp and .tga files from the wwiVerdun directory.



OPTION 2 - Add the terrain so it can be selected when flying Single Mission

1) You must have First Eagles Patch 2 or later for this to work.  You can get the path here if you don't already have it: http://www.thirdwire.com/downloads_fe.htm.

2) In the C:\Program Files\ThirdWire\WWI\Terrain directory, create a new subdirectory called winter_max188.

3) Unzip the contents of this download into the directory you just created (C:\Program Files\ThirdWire\WWI\Terrain\winter_max188)

4) Copy the wwwVerdun.CAT file from C:\Program Files\ThirdWire\WWI\Terrain\wwiVerdun to the winter_max188 directory.

5) You can now select Verdun, France- Winter as one of the Mission Maps when loading a Single Mission.






Notes:



1) The Terrain Texture setting under Graphics Options must be set to High to fully utilize the hi-res textures.

2) If possible, enable anisotropic filtering in your video driver settings.  It will allow you to see the detail in the terrain for a much greater distance.

3) I don't notice any decrease in frame rates using the hi-res terrain on my system (256MB video RAM). However, if video RAM is a bottleneck on your system, it may impact performance.

4) Paint Shop Pro 7/8 was used to edit the tiles.

5) If you want to modify this terrain set for your own use, that's great.  However, please don't repackage and redistribute it without asking me.



max188
http://www.xmission.com/~mmagleby/eaw

Rev 1.0 - 3/10/07  Hi-res Winter Terrain for Third Wire's First Eagles





