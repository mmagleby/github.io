Mosquito Mk III

This is a De Havilland Mosquito Mk III based on the HT-E (RR299), a T Mk III which was built at Leavesden between October 1944 and July 1945. It was the last wartime Mosquito flying in the U.K. when it crashed at Barton Airshow on the 21st July 1996. 

Improved 3d model provided by Stag and JWC.


INSTRUCTIONS 

1) Unzip all the files to a directory.

2) Copy the *.tpc and *.3dz files to your EAW directory.

3) You're Done!  Hope you like this Mossie!


Notes:

1) If you use a skins management program like STAB or Skins-n-More, you should copy the *.tpc and *.3dz files  to the appropriate directory instead of the EAW directory.  Check the program's documentation on how to set this up

2) This skin is compatible with both TNT and 3dfx.

max188
http://www.xmission.com/~mmagleby/eaw

Rev 1 - 7/1/01 - Mosquito Mk III
