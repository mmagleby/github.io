EAW Sound Collection

This is the collection of sounds that I use in EAW.  Many of these are Serb's sounds, and some are Meatwaters.  Others I have created or adapted myself to get the sound I like.  I'm not entirely sure anymore who is the creator of each individual sound, so you may want to check out Serb's site or Meatwater's soundpack to download some of the original files.  I don't take any credit here for original work, just offer this as a convenient way to get what I consider the best sounds in a single download.



Instructions:

1) Unzip all the files to a directory.

2) Copy the .snd files to your EAW directory


Here is a list of the files.  If you want to go back to the default sound for a particular sound, just remove its cooresponding .snd file from your EAW directory.


snd0003 Flak Explosion
snd0004 Bomb Explosion
snd0005 Crash
snd0006 Crash
snd0008 Water Crash
snd0009 Bomb Release
snd0010 Bullet Hit
snd0011 Bullet Hit
snd0012 Riccochet
snd0013 Riccochet
snd0014 Riccochet
snd0015 Bullet Hit
snd0016 Riccochet
snd0018 Riccochet
snd0019 Flak Shot
snd0020 Flak Hit
snd0022 Explosion
snd0023 Explosion
snd0025 .30cal MG
snd0026 .50cal MG
snd0027 20mm Cannon
snd0028 30mm Cannon
snd0029 Rocket Launch
snd0030 Radial Engine start
snd0031 Radial Engine
snd0034 In-line Engine start
snd0035 In-line Engine
snd0038 Jet Engine start
snd0039 Jet Engine
snd0042 German Bombers
snd0043 U.S. Bombers
snd0044 V-1
snd0047 Engine failure
snd0050 Landing Gear
snd0051 Parachute Opening
snd0052 Touchdown
snd0053 Distant Explosion


max188
http://www.xmission.com/~mmagleby/eaw