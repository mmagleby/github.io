European Air War Control 

This utility *must* be installed to your
European Air War Directory.
If you get a complaint that the programme can't
find the ini file then that's a sure sign you
didn't install this utility to the right location. 
Uninstall and try again.
Before using the higher resolutions, please consult
your monitor manual and/or video card manual to see
if any or all of these are supported.
This utility requires the new v1.2 patch in order
to function correctly.
--------------------------------------
New for version 2000

Major graphical changes and enhancements.

Added the option that changes your Wingman and Leader 
symbols placed on the aircraft ID labels. 

The option to change your on screen information and
 aircraft label ID colour. 
Now you can adjust the colours for both friendly and
 enemy information/ID labels with three sliders that
 enable you to mix and view your own palette instantly.

Context sensitive help. Click on the ? icon in the top
 right corner of the control then point and click on an option.
This will bring up a help window on what that particular
 button or slider does.
Pressing the F1 key after selecting a button or slider will
 do the same as above. 

Added an extra slider for force feedback gain adjustment to
 the Joystick options page.
 
Fixed a bug on the Roger Wilco page. Adding a new IP address
 then reselecting the name from the list gave 'No IP added'. 

Added a minimise button that hides Eaw Control on the traybar
 next to the clock.
Click the right mouse button over the Eaw control icon and
 choose maximise to view again.

Fixes:

Fixed the bug when adding a new ip to the roger wilco page.
The list failed to update the new ip if you chose to select the
name after adding it. 

Hopefully the bug that caused an invalid variant error has
 been squashed. This was mainly due to foreign languages/keyboards
 that use a character other than a dot for decimal usage.




New for Version v1.6

Fixed up the code, a major revamp.
Now it doesn't matter where/what you have in your ini
file, the values are written to the correct areas.
The last versions didn't like anything but a bog
standard ini file when changing values.

Launching EAW will now close down the control.

Changed the overall look of the control to match
my latest Fighter Squadron(tm) Control (SDOE Control).
App will now fit in your pocket! ;)

Added a few new commands available with the 1.2 patch
for both single and multiplayer.

Patch readme file included and viewed via a button on
the control.

Added a page where you can add names and IP addresses
for internet/network connections. It was written primarily
for use with Roger Wilco to help aid the retrieval of user
names and IPs.

A button to launch Roger Wilco if it exists on your system.

History:

v1.5

Added more resolution options to a maximum of 1600 x 1200.
Added an extra control to adjust flight sensitivity.
Now shows last modified resolution each time you use the utility.
Extra text in the helpfile and slight layout modifications.


v1.4

Launches Notepad to allow editing the ini file manually.
Launch EAW from the control panel.
Improved helpfile and graphics.


v1.3

New Features: Joystick settings.
Joystick deadzone, Windows Joystick enable/disable and
Force Feedback On or Off.
Help file added to application.
