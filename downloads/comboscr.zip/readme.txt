Fuel Script w/Rendermod

EAW models fuel characteristics within the game, but for some reason the consumption rates are set so low that you will rarely, if ever, need to worry about fuel levels.  Plus, with the default values, the combat radius ends up being about double what is shown in the game.  This mod allows you to adjust the fuel consumption rate to make the game more accurate and adds a new dimension to the gameplay of managing fuel in a more realistic manner.

This script will modify the fuel consumption rate values for plane slots in a given planes.dat file. It prompts you for the multiplier you want to use when you run the script.

The script can either read in the existing values or use the default values as a base on which to apply the multiplier.  You will want to read in the existing values if you are using ECAPanel or a custom planes.dat.  If you are using a default planes.dat file with the original planes, you will want to use the default values.  

Be aware that you will should not run this script twice against the same planes.dat file without resetting the planes.dat file in between.  Otherwise, you will essentially be appling the modifier twice.  This script will prompt you to reset the values for a default planes.dat, but if you use ECAPanel, you will need to reset the file within ECAPanel.

The script will also prompt for excluding the original non-flyable planes from processing.  You may want to use this option for the default planes.dat so these planes will not have any fuel concerns.

Finally, you can apply the rendermod changes with this script.  This makes EAW use the higher quality plane rendering models for longer distances.  See the rendermod.txt for more details.

This script will backup the existing planes.dat as planes.dat.prefuelmod.  If necessary, you can revert to the original file by renaming this file back to planes.dat.


INSTRUCTIONS:  This script is written to be run by ASHE. You can get the runtime version of this program from http://www.grandriversoftware.com/download/index.shtml Install ASHE RT and then open the fuel_scr.txt and run it. When you run the script, it will prompt for the location of the planes.dat file, prompt you for the necessary input, and make the cooresponding modifications. It can be run against any planes.dat file.  Although this script will automatically backup your planes.dat file, you should manually back up the file as well before running the script.


DETERMINING A MULTIPLIER TO USE

Basically, the fuel burn rates are about half of what they should be for each plane.  However, because the game manages the player fuel and AI fuel differently, we unfortunately can't just double the rates without causing problems for the AI.


Here are some general observations about fuel treatment in the game that affect how we can fix this problem:

The fuel consumption rate is half what it should be according to combat radius.  This is the same for all planes.

The fuel burn rates apply the same to both player and AI planes.

Using alt-n conserves fuel equally for both human and AI planes.

In EVERY OTHER SITUATION (even if flying alongside the player or on autopilot), the AI will ALWAYS use more fuel than human player.

The AI cannot correctly gauge remaining fuel to determine when to return to base.

The AI cannot conserve fuel.

The AI cannot land or bail out if it runs out of fuel.

The human player is smarter than the AI.


Based on these observations, here are some general guidelines for deciding on a burn rate multiplier to use based on your style of play and squadron ranking.  These are just  suggestions based on some preliminary testing, you may want to experiment with your own values to use.  

2.0 - Combat radius as listed in the game will be accurate for the player, but AI WILL have problems and crash in fuel critical situations.

1.75 - AI should be okay if you use alt-n to conserve their fuel AND can order them to return to base in time.  You are basically managing your squadrons fuel levels rather than your own.

1.66 - AI should be okay if you use alt-n to conserve their fuel OR can order them to return to base in time.

1.5 - AI should generally be okay when left on their own, but be careful.

1.0 - The game's original values.  "Fuel gauge? I don't need no stinkin' fuel gauge!"


Please give me any feedback you have on what values have worked well for you!


max188
8/8/01 - Initial Low Fuel Script
9/3/01 - Version 2
10/6/01 - Fixed problem with saving out file properly


http://www.xmission.com/~mmagleby/eaw