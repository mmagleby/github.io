The 3D ground objects in the game use 2 of 24 different tpc files (12 pair for the original objects).  For example: grnd01s. and grnd01.tpc contains the artwork for the factories.  Geo and Moggy discovered that if you use the large file for both (replacing the Grnd*s.tpc with the Grnd*.tpc and just renaming it Grnd*s.tpc) the objects have much more detail.  It also appears the game may not even use the Grnd*.tpc file, only the Grnd*s.tpc being necessary.  (However, I think the game may still extract the larger file from the Compressed Data Files during game play so I still use both to save on performance).  At any rate, the difference is often startling.  The objects actually have depth.

The files contained are just the default Grnd*.tpc files reconfigured so they are all the large version of the particular file.  If, like me, you are using a variety of custom made Grnd*.tpc files (red-roof building, winter buildings, etc.) you should not over-write any of those files with these.  In other words these should not be replacing any files you are using.  To convert these or any custom ones yourself is easy.  Find a custom made Grnd*.tpc file, copy the standard, larger one, rename it Grnd*s.tpc and use it instead.  Many of the add-ons already do this, but the red-roof buildings, for instance will need to be updated this way.

Also enclosed is Harry McWilliams' 3D Ground Object Files List so you can tell what each tpc file is for.

Hope you find this helpful.

Michael "RedEyes" Lask

mjlask@ameritech.net 
