3DForestKill
10/9/2000

This kills only the 3D forests by replaceing them with the Kubelwagen shadow. This is visible as a grey square on the ground, so it may not be appropriate with desert/med terrain.

HarryM@Redshift.com