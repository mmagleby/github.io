Hi-res Buildings for Third Wire's First Eagles

This is a hi-res replacement building set for First Eagles.  It replaces or enhances most of the buildings in the game.  Many of the replacement buildings use completely new hi-res textures, while a few buildings are enhanced versions of those included with the game.  The shapes and locations of the buildings are not changed.

INSTRUCTIONS 

1) Back up your existing ..\ThirdWire\WWI\Terrain\wwwiVerdun directory.

2) Unzip the contents of this zip file into the existing ..\ThirdWire\WWI\Terrain\wwiVerdun directory.  You will see 23 new .bmp files  files in the directory.

3) That's it, you're done.  Run the game and enjoy the new buildings!



Notes:

1) If you want to go back to the default buildings, just delete the new .bmp files from the wwiVerdun directory.

2) The Object Texture setting under Graphics Options must be set to High to fully utilize the hi-res buildings.

3 If the hi-res buildings cause performance issues in your system, I have included a normal-res file for the main buildings. Just copy this to your wwiVerdun directory and  overwrite the hi-res file.  It will still look a lot better than the stock buildings.

4) Paint Shop Pro 7/8 was used to edit the tiles.

5) If you want to modify these buildings for your own use, that's great.  However, please don't repackage and redistribute it without asking me.



max188
max188@xmission.com
http://www.xmission.com/~mmagleby/eaw

Rev 1.0 - 2/17/07 Hi-res Buildings for First Eagles






