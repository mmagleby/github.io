Find-a-Skin 3.1  - 14/05/2001  
By Spit9

*** MANY THANKS TO...
- Matttm, for the great EAWStab;
- RedEyes and Stanley99, for their patience and great help testing this utility;
- All my friends at EAW Forum that are testing it yet;
- Aces High, for the basic ideia;
- PipsJG26, for requesting and testing these last enhancements.

*** WHAT IS IT?
	Find-a-Skin is a utility developed to help the management of a large number of EAW skins. It was NOT intended, in any way, to take the place of the great addon that is Stab, but just to complement it in some aspects. In a few words, Find-a-Skin is a viewer that allows to quickly find a particular skin among the Stab database. In fact, Find-a-Skin uses Flugzeugwerke, the folder that contains all skins registered in Stab. So, you *need* to have Stab installed in order to use Find-a-Skin.
	The reason for its development was the fact that when that database grows up to 300 or more different skins, it becomes hard to remember if you have or not a particular skin, or what skins are based on a particular plane or even just find it among all those others. Stab can shows the skins you have, but does it showing the available skins one at a time for each base plane and for a specific terrain/season), while Find-a-Skin shows you all at once, side by side, regardless of season or terrain, to a maximum of 400 skins (20 pages of 20 each) for each base plane.

*** HOW IT WORKS?
	Find-a-Skin asks for a base plane and then searchs the Stab database (the Flugzeugwerke folder) to find all skins based in that plane. Then it shows all these skins in the subsequent pages, with the number and name of each model in Flugzeugwerke. These pages include the name of the base plane, the number of skins found and the date of the search, and can be printed to make a comprehensive catalog of skins.
	Find-a-Skin can also do (as Stab does) a copy of a selected skin to the EAW directory, if you want (even it being not its primary function). Then all you need to do is to launch EAW and select the correct base plane. 

>>>>>>>>>>>>>>>>>

	ATTENTION!! 
	- Find-a-Skin will ONLY recognize images in the .JPG format (the most common). You will need to check if you have some pictures in another format (like .GIF) in your Flugzeugwerke folder! If yes, you need to convert them to .JPG using any good graphic program as PSP, COREL, ADOBE, IRFANVIEW, or even Picaview. Otherwise, Find-a-Skin will not show these images (although it will do all the rest). 
	- Find-A-Skin can copy skin files to EAW folder, but it will erase the *.TPC, *.3DZ and VCG_*.DAT files in EAW that match the  selected plane (and any LOADOUT.DAT file, if present) before loading the new ones. 
	- Find-a-Skin was not tested with STAB 3.0! 

>>>>>>>>>>>>>>>>>

	
*** HOW TO INSTALL?
	All you need to do is to create a folder under your EAW directory, name it FindASkin (or whatever you want) and then unzip the FaS31.zip to it.
	The two .JPG files (NoSkin.jpg and NoPic.jpg) MUST be moved (or copied) to the \EAW\Addons\Flugzeugwerke folder.
	Until now, I think there's no need for extra .DLLs. 
	Stab database MUST be installed under EAW folder as \EAW\Addons\Flugzeugwerke (don't use other names for these two last folders!). You can launch Find-a-Skin by double-clicking FindSkin.exe, creating a shortcut to your desktop or using Stab. Find-a-Skin will not make any changes to EAW or Stab, so it is harmless. 

*** CHANGES FROM v. 3.0:
	- FaS 3.1 can now recognize up to 2500 skins, and 400 different skins per each "base plane".


If you have any problem, please contact me at spit9@terra.com.br.


Have fun!... 
