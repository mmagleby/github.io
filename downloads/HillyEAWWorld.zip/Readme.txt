NEW HILLY EAW  WORLD

This is a file that makes the original EAW landscape hilly : hills, valleys with rivers and mountains. 
However, it does not intend to make the european landscape "topographically-exact".
All airbases and ground targets lie in horizontal areas so that any of them are usable in single missions and campaigns.
This improvement can be used with all yet-existing terrains except for the pacific-like terrains.
For the pacific terrains, an all-flat landscape was already released. It can be downloaded from either Cord's or Alain-James' site
(http://eaw.thrustmaster.com/frames.html or http://spower.free.fr/).

Just copy the EAW16.HM file into your main EAW directory to install.
Erase the file to uninstall.

Known unfixed bugs with (probably no chance to be fixed) :
- Under low angles and at low altitudes, the airbases/targets may be seen through the terrain skins. This is also true for the railroads.
- Ground objects other that those of airfields and targets may not be horizontal. In particular, the 3D forest may give some odd results.
I recommend to use  HarryM's WindMillKill.ZIP utility which eliminates 3D forests and many buildings.
- Rarely, but sometimes,  the enemy aircraft may crash when "low altitudes missions" are played in mountaineous areas.

Contact me if you observe other problems.

I hope you'll enjoy. Much more to come ...

September 2000

Note:  the accompanying screenshot could be named : "A Morane-Saulnier in the Ardennes, Battle of France 1940). 
The great spring terrain is from C. Lumpkin. 

Dominique "DOM" Legrand
Dominique.Legrand@univ-lille1.fr 
