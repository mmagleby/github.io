EAW People

This improves the look of the little blue people that you will see in EAW as both troops and civilians.  Basically, they are not blue anymore, have been enlarge a bit, and have been given somewhat of a face.  They still don't look that great, as there is really not much to work with.  But, at least they look at bit more realistic.


INSTRUCTIONS 

1) Unzip all the files to a directory.

2) Copy person1.spt and hwshells.spt to your EAW directory.


max188
http://www.xmission.com/~mmagleby/eaw

7/23/01 -- EAW People
11/23/01 -- Added war casualties, enlarged people