GeForce Briefing Screen Fix

This fixes the Briefing Screen and Map corruption problems when running EAW on an Nvidia GeForce series card.  It adds an entry to to the Windows system registry for Nvidia cards called "NoAdjustedPitch".  

Thanks to No105_Ogdens, who provided the final clue in narrowing down the cause of this pesky bug. 


Installation:

1) Doubleclick on the geforcefix.reg file.  

2) Click yes when it asks if you want to add the information to the registry.

3) Restart Windows.

4) That's it. Run EAW and the briefings and maps should be working.



Notes:  

1) This is for Win95, Win98, or WinME only!

2) This should work for all GeForce cards (Geforce, Geforce2, Geforce3), but has not been tested on all possible combinations of drivers, chipsets, and vendors.

3) This key was originally set on TNT cards, but for some reason it was dropped starting with the GeForce card.  This is why the briefing screens worked fine on the TNT series, but not on the GeForce.  It is unknown what effect setting this key could have on other games.  I have not seen any problems myself.

4) If necessary The key can be removed through regedit.  If you choose to do this, be very careful you do not delete or change anything else you do not intend to!  The procedure is very straightforward, but very dangerous if you are careless.  Here are the steps:  A) Go to Start / Run, type in regedit and hit enter. B) Hit F3 and search on NoAdjustedPitch.  C) Hit delete once it finds and hilights the NoAdjustedPitch key name.  D)  Restart and you are back to where you were before adding the key.


max188
http://www.xmission.com/~mmagleby/eaw
1/27/02
