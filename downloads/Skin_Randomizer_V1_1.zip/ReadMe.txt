***** SKIN RANDOMIZER FOR EAW v1.1 ********************

Skin Randomizer v1.1 differs from v1.0 by the only Rdpl2.cct file whose source code
has been modified. The unability of v1.0 to load skins from subfolders 10-15 is fixed.

If you already installed Skin Randomizer, just replace the former Rdpl2.cct (15/11/2001)
with the new one (20/11/2001). Sorry for the trouble !


===== INTRODUCTION: 

There are tons of different skins for every aircraft in EAW. Unfortunately, in most
campaigns and single missions, a single skin per aircraft slot is allowed.

This utility manages up to 15 skins per aircraft slot (30 slots). You can decide 
for different slot status :

1) Disabled : Even if skins are present, they will not be loaded.
2) Default : You can decide for a default skin. That only skin will be loaded, 
   even if several skins are available for the a/c slot. You will use that 
   option to select the skin of a given aircraft you will fly during campaigns
   and single missions.
3) Randomized. The program will randomly choose and load a skin among others
   present in the slot.

The utility can be used with any EAW install. However, you don't need it with 
AITW40 ('Attack-in-the-West 1940'). AITW40 already possesses the 'skin 
randomizing' feature.

The utility automatically manages all file transfer tasks. However, when setting
up the utility, you will have to fill the skin subfolders in a manual way. Unfortunately, direct links to popular skin/theme managers (EAW Stab, Skin'n more,
Theme manager) are not available but this could be fixed in the future.


===== SETTING UP THE SKIN RANDOMIZER UTILITY:

The zip contains 7 files :
- Random.exe : the executable file
- Rdpl1.cct
- Rdpl2.cct
- Randpath.fil
- Randompl.fil
- Tpn.fil
- this readme.txt

All these files must be copied into the main folder of your EAW install 
(the folder which contains EAW.exe). The default path to EAW is usually 
C:\PROGRAM FILES\MICROPROSE SOFTWARE\EUROPEAN AIR WAR\ but it can be 
changed to whatever you want. Of course, the utility can be used with 
any already-existing EAW install (Pacific Tide, Bob ...). As said, don't 
use this utility with AITW40.

Run Random.exe

When on the main screen, type 'A' to go to the Set-up/Update screen.

Type '1' to go to the path set-up screen.

Enter the full windows path to your EAW install (in block letter) and 
add ZZZ.ZZZ at the end of the path. 
For example : C:\PROGRAM FILES\MICROPROSE SOFTWARE\EUROPEAN AIR WAR\ZZZ.ZZZ

Then, check the contents of the folders and answer to the questions. At the 
end of the process, the DOS path should be determined. 
Type 'Y' to update the path.

When back to the main screen, type 'A' again and '2' to go to the aircraft
subfolder management screen. The program will indicate that the subfolder tree
does not exist. Type 'Y' to continue. The program will create a new folder 'SKINS'
in your EAW install with 30 a/c subfolders themselves containing 15 subfolders named from 1 to 15. When over, the program will lead you to the aircraft subfolder
manager (just behind an explanatory screen). You can see that all a/c subfolders
have the 'D' (disabled) status and no available skin subfolder. That's quite normal 
since no skins are present in these newly-created subfolders.
Press enter to go back to the main screen and 'Q' to quit the program : the set up
is over !


===== INSTALLING THE SKINS INTO SUBFOLDERS :

The utility was designed to select/load a skin among several others for each
aircraft slot. If no skins are copied for a given aircraft slot, this slot will
be disabled and the default EAW skin will be used. If one skin is present, that 
skin could be used as default. If several skins are copied, one skin could be 
choosen in a random way. 

Copy your skin files into the skin subfolders. You must fill the subfolders one by one without gap in the subfolders order, i.e. 1, 2, 3, 4 and so on ... If you miss subfolder '2', then subfolders 3 and 4 will be ignored by the program. As well,
to be taken into account by the program, a skin subfolder must contain, at least, 
a P****tex.tpc file corresponding to the aircraft slot. For example, subfolder 1
of the aircraft folder 109E must contain a P109Etex.tpc file (the "minimum" file 
for a skin). If not, subfolder 109E\1 will be considered as empty.

Apart from p*.tpc files, all other skin files like p*.3DZ, vcg_*.dat can be copied
into the skin subfolders. The whole content of the subfolder will be copied into the main EAW folder when required (no file filter).

===== MANAGING THE AIRCRAFT SUBFOLDERS :

Run Random.exe

Type 'A' to go to the Set-up/Update screen.

Type '2'  to go to the aircraft subfolder manager.
The aircraft slot table will still display disabled folders (red lines and 'D').
However, according to the skins you dropped into the subfolders, the number of 
available skin subfolders now automatically appear on the right. Type the letter
of the aircraft slot you want to modify and press Enter.
While on the specific a/c slot screen, you can change the status by hitting 'S'.
Then, go back to the a/c subfolder table screen by entering 'B' and repeat the 
same operation for the other a/c slots. 

Note : Every time you will make changes to the skin subfolders contents (add/delete
skin files), go to the aircraft manager to update the changes.


===== RANDOMIZING THE SKINS :

When your skin manager settings are OK, you can randomize the skins by 
hitting 'B' "Randomize now" on the main screen. The program will automatically
load the skin files into the main EAW folder. 
Warning : In order to avoid casual skin files conflicts, the program will 
automatically delete all p*.tpc and p*.3DZ files from the main EAW folder 
before loading the new skin files.

Run the utility and hit 'B' every time you want to change the skins. It is not
necessary to quit EAW, just press Ctrl + Esc to go to the desktop. 
Run the utility, hit 'B' and go back to EAW. Keep it simple !


I hope you'll have fun with this utility.


Dominique 

November 2001

Dominique.Legrand@univ-lille1.fr
