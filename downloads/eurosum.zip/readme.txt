Hi-Res Summer European Terrain

This is a hi-res summer terrain for the EAW European theater.  It includes the complete terrain as well as matching airfields.

Also included is HarryM's 3DForestKill files to get rid of the ugly 3dforests which are even uglier with this terrain.

Geforce series graphics card owners read note 3!

Some of the terrain textures are based on CFS2, FS2K2, and Original EAW tiles.  Paint Shop Pro 7 was used to for all modifications.  PicPac was used to convert the tiles to EAW format.  This terrain should be compatable with both TNT and 3DFX cards.  I hope you like the it!


INSTRUCTIONS 

1) Unzip this package to a directory.

2) Double-click on the make_bn.bat file to create the cooresponding bn*.ter files.

3) Copy all the *.ter files to your EAW directory.

4) Copy the *.tpc files from the airfields directory to your EAW directory.

5) Copy the *.3dz files from the 3dforestkill directory to your EAW directory.

6) You're Done!  Run the game and enjoy the terrain!



Notes:

1) If you use a terrain management program like STAB or Skins-n-More, you should copy the files to the appropriate terrain directory instead of the EAW directory.

2) I recommend DOM's Hilly EAW World to add more variation to the terrain height.  You can download it from my site under the Classic EAW Guide section.

3) If you have a GeForce series graphics card, I highly recommend enabling anisotropic filtering.  This minimizes texture shimmering and makes a HUGE difference in visual quality, especially in this highly detailed terrain.  You will need the latest nvidia drivers 40.72 or later.  Anisotropic filtering can be set through the control panel under the Direct3D settings.

2) If you have problems running hi-res terrains, a normal resolution patch is available on my site.

5) I left out the pcx files to make the package smaller, but I have no problem providing them to anyone who wants to look at, modify, or do whatever to them.  Just send me a request.


max188
http://www.xmission.com/~mmagleby/eaw

Rev .9 - 1/6/02 - Initial release, with futher refinement planned
Rev 1 - 11/30/02 - minor tweaks
Rev 1.1 - 1/1/03 - fixed pallete problem on 3dfx cards