Hi-Res Summer EAW Terrain

This hi-res terrain set is based on the original EAW terrain tiles.  The tiles have been reworked and enhanced to improve the overall visual quality, while still maintaining the classic look of the original terrain.  You may also notice some additions like snowy mountains and enhanced textures.

This terrain was created using picpac and the supplied standard EAW terrain tiles.  Paint Shop Pro 7 was used to for all modifications.  This terrain should be compatable with both TNT and 3DFX cards.  I hope you like the it!


INSTRUCTIONS 

1) Unzip all the files to a directory.

2) Double-click on the make_bn.bat file to create the cooresponding bn*.ter files.

3) Copy the *.ter files to your EAW directory (there should be 118 of them).

4) You're Done!  Run the game and enjoy the terrain!



Notes:

1) If you use a terrain management program like STAB or Skins-n-More, you should copy the *.ter files  to the appropriate terrain directory instead of the EAW directory.

2) I have not found that the hi-res terrains cause any performance hit over the regular terrains in my testing, but its possible that with a low-end system or video card you may get some performance degradation.

3) I left out the pcx files to make the package smaller, but I have no problem providing them to anyone who wants to look at, modify, or do whatever to them.  Just send me a request.


max188
http://www.xmission.com/~mmagleby/eaw

Rev 1 - 3/12/01 - Hi-res original terrain
Rev 2 - 4/5/01 - Cleaned up and enhanced colors
Rev 3 - 5/5/01 - Fixed seaming and repeating patterns
Rev 4 - 5/10/01 - Added more snow to mountains
Rev 5 - 5/18/01 - Fixed stray color pixels
Rev 6 - 6/17/01 - Colorized some fields.  Adjusted contrast
Rev 7 - 3/7/02 - Added texturized water, fields 
Rev 8 - 12/8/02 - color tweaks, town texture changes
