EAW Effects Pack

This add-on enhances many of the effects that EAW uses including smoke, fire, explosions, flak, hit debris, muzzle flash, and tracers.  The game still renders these effects the same way, but the colors, textures, and detail are enhanced.  



INSTRUCTIONS 

1) Unzip this package to a directory.

2) Copy the .spt files to your EAW directory.

3) Enjoy the enhanced effects!


Notes:

1) You can revert to the original effects by removing these .spt files.

2) This mod should have no impact on performance.

3) The tracers share the same colors as the lens flare, so you will notice the coloring of the lens flares are a bit different.  You may turn off lens flare under graphics options if desired.

4) The tracers have different colors depending on the gun size.  The categories are large cannon, small cannon, large caliber, and small caliber ammo loads. 

5) This package includes optional tracer files for default, medium bright, bright, smoke, green, and solid muzzle tracers.  If you wish to use any of these, just rename the appropriate file to hwexplos.spt and copy it to your EAW directory.  You may want to turn off lens flare with some of the tracers.

6) If you want to create your own tracer colors, you can edit the hwexplos.pcx file and use picpac to convert to an spt file.  The tracers are built from the 4 color boxes (from left to right): muzzle flash and large cannon, small cannon, large caliber, and small caliber.  Keep in mind all but the large cannon are also used as lens flare images.

8) At distance, all tracers change to a yellow/orange dot, and are not affected by this mod.


max188
http://www.xmission.com/~mmagleby/eaw


7/6/01 -- EAW Smoke
8/13/01 -- EAW Fire and Tracers
8/30/01 -- EAW Effects Pack
8/31/01 -- Added additional tracer files, minor smoke fix
12/10/02 -- minor smoke change