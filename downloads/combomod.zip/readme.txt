Plane Rendering and Fuel Mod

This mod is basically two unrelated mods combined into one.  It provides a custom planes.dat file that affects Plane Rendering and Fuel Consumption values as outlined below.  Planes.dat files are included for several popular flight models and campaigns.


--------------------------------------------


PLANE RENDERING MOD

This causes EAW to use higher quaility plane rendering models for longer distances. This makes it easier to identify the type and orientation of the plane at further distances (See render2.jpg). It also increases the distance that planes are visible as dots.


How it works:

Planes are rendered in 5 stages in EAW depending on their distance (See render1.jpg for examples).

1) Full quality textures and 3d models
2) Simplified textures and 3d models
3) Flat textures
4) Lines
5) Dots

The distance that each rendering model is used was doubled from the defaults. Ie., the full quality model will be used up to 200 feet instead of the usual 100 feet. The distance that the plane is visible as a dot was increased by 50%. Each type of plane uses different baseline values.

The logic behind this is that the original values were optimized for the game's default 640x480 resolution. Now, with 1280x960 and similar resolutions available, we have twice the resolution to work with. So, we can extend the rendering models out twice as far to capitalize on these higher resolutions. Of course, if you are not running at a resolution higher than the 640x480 default, you probably won't benefit much from this.

The change in maximum visibility distance as a dot equates to about 21 miles for the largest bomber to about 12 miles for a fighter (as near as I can tell).


--------------------------------------------


1.5 FUEL BURN RATE MOD

EAW models fuel characteristics within the game, but for some reason the consumption rates are set so low that you will rarely, if ever, need to worry about fuel levels.  Plus, with the default values, the combat radius ends up being about double what is shown in the game.  This mod sets the fuel consumption rate to 1.5 times the default for all planes, including AI.  This makes the game more accurate and adds a new dimension to the gameplay of managing fuel in a more realistic manner.  Please see note 3.


--------------------------------------------


INSTRUCTIONS 

1) BACKUP any existing planes.dat file in your EAW directory.

2) IMPORTANT: Determine which planes.dat file in this package you will need to use. Many add-ons make changes to the planes.dat file so you will need to use the correct one to maintain these changes. Files are provided for the following add-ons:

    ECAO1.4
    ECA1.4 (excluding ECA Panel)
    Emil's Bob (includes 6/28 update) 
    1942 ETO    
    Pacific Tide 2.0 
    Midway 
    Poland 1939 		see note 4
    France 1940 		see note 4
    France 1940 RAF Edition     see note 4
    Mediterranean 1941 A/B 	see note 4
    Caucasus 1942 		see note 4
    Tunisian 1942 		see note 4
    Default EAW (All versions)
  
If you are using any other campaign that has its own planes.dat, or use ECAPanel to customize plane slots, you will want to download the Fuel Script w/Rendermod.  This allows you to make your own changes to custom planes.dat files 

In addition, since ECAPanel rewrites the planes.dat file, it will not work with this utility.

3) Locate the planes.dat file in the appropriate directory in this package and copy it to your EAW directory.

4) That's it. Now just run EAW as normal.

--------------------------------------------

Notes:

1) Although I did not notice any frame rate hit on my system (PIII 900, Geforce2 GTS), the rendering mod may cause a performance degradation depending on your hardware setup.

2) You will not want to use this mod for online play, as planes.dat is one of the files that EAW checks for consistancy between players. However, if all the players are using the same file, you should be okay.

3) Although a x2 burn rate is more accurate for player-controlled planes, it cause problems for the AI. As a result x1.5 was chosen as a good compromise to allow more realistic fuel management by the player, while not affecting AI negatively.  If you want to adjust the rate, please download the Fuel Script w/Rendermod, which allows the player to choose custom burn rate settings.

4) To remove this mod, delete the new planes.dat file from your EAW directory and copy over the one you backed up earlier.

5) Thanks to Charles Gunst for documenting these hex values in his EAW Editing Notes. Charles and many others have put forth a huge effort in making the game what it is today.

6) Rendermod changes for some of the campaigns were done by vonOben.  Following are his notes on these:

The following aircraft have been selected for the campaigns:

Poland 1939
Polish aircraft selected in ECA Panel as follows:

Hurricane:	PZL P.11c
Spitfire I:	PZL P.24a
Mosquito:	PZL P.37b
P 51 B:		PZL P.23b
Bf 109 E:	Bf-109 E1
Bf 109 G:	Hs-123 A1
Bf 110 C:	Bf-110 C4
Ju 87 B:	Ju-87 B2
Ju 88 A:	Do-17 Z2
He 111 H:	He-111 H2

France 1940
French aircraft selected in ECA Panel and individually as follows:

Hurricane:	Morane MS.406
Spitfire I:	Dewoitine D.520
Spitfire IX:	Caudron C.714
Spitfire XIV:	Bloch MB-155
Typhoon:	Curtiss Hawk 75A
Tempest:	Bloch MB-152
Mosquito:	Potez 631
P 38 J:		Fokker G-1 Mercury
P 51 B:         Fairey Batle MkI
B 26:		Amiot 354 B4
Fw 190 A:	Macchi C.200
Ju 88 A:	Do-17 Z2
Bf 109 E:	Bf-109 E3
Bf 110 C:	Bf-110 C4
Ju 87 B:	Ju-87 B2
He 111 H:	He-111 H2

France 1940 RAF Edition
French aircraft selected in ECA Panel and individually as follows:

Hurricane 	Hurricane I
Spitfire I	Spitfire I
Spitfire IX 	Gladiator I
Spitfire XIV 	Bloch MB-155
Typhoon 	Defiant I
Tempest 	Skua II
Mosquito 	Wellington I

P 51 B 		Fairey Battle I
P 51 D 		Fokker D-XXI
P 38 H 		Beaufighter IF 
P 38 J 		Fokker G1 Mercury
P 47 C 		F6F-3 (Martlet)
P 47 D 		Hurricane I
B 26 B 		Blenheim I

Bf 109 K  	Ju-87 B2
Fw 190 A8  	Macchi C.200
Fw 190 D9  	Fiat CR-42
Ju 88 A:	Do-17 Z2
Bf 109 E:	Bf-109 E3
Bf 110 C:	Bf-110 C4
Ju 87 B:	Ju-87 B2
He 111 H:	He-111 H2

Mediterranean 1941
North African aircraft selected in ECA Panel and individually as follows:

Hurricane:	Hurricane IIc
Spitfire I:	Spitfire IIb
Spitfire IX:	Spitfire Vb
Typhoon:	Tomahawk Ia
Tempest:	Kittyhawk II
Mosquito:	Beaufighter IF
P 47 C:		F4F-3 Wildcat
B 26 B:		Blenheim I 
Bf 109 E:	Bf-109 E8
Bf 109 G:	Bf-109 F4
Bf 110 C:	Bf-110 F1
Me 410 A:	Me-210 A1
Ju 87 B:	Ju-87 D7
Ju 88 A:	Ju-88 A4

Caucasus 1942
Russian aircraft selected in ECA Panel and individually as follows:

Hurricane:	MiG-3
Spitfire I:	LaGG-3
Spitfire IX:	Yak-9D
Typhoon:	La-5
Tempest:	Kittyhawk II
Mosquito:	Pe-2
P 47 C:		Su-2 
P 47 D:		Il-2 
B 26 B:		Il-4
Bf 109 E:	Bf-109 F2
Bf 109 G:	Bf-109 G2
Bf 110 C:	Bf-110 F1
Ju 87 B:	Ju-87 D7
Ju 88 A:	Ju-88 A4
He 111 H:	He-111 H2

Tunisian 1942
North African aircraft selected in ECA Panel and individually as follows:

Hurricane:	Hurricane IIc
Spitfire I:	P-39 Q Airacobra 
Spitfire IX:	Spitfire Vb
Tempest:	Kittyhawk II
Mosquito:	Wellinton Mk I
P 51 B:		P-40 E 
P 38 H:		P-38 H
P 47 C:		F4F-4 Wildcat
P 47 D:		Hurricane I
B 26:		B-25 Mitchell
Bf 109 E:	Macchi C.202
Bf 109 G:	Bf-109 F4 
Bf 110 C:	Bf-110 F1
Me 410 A:	Me-210 A1
FW 190 A:	Fw-190 A4
Ju 87 B:	Ju-87 D7
Ju 88 A:	Ju-88 A4
He 111 H:	He-111 H2


Per "vonOben" Rasmusson
2001-08-11

per.eslov@spray.se


--------------------------------------------


max188
http://www.xmission.com/~mmagleby/eaw


6/26/01 -- EAW Plane Rendering Mod
7/10/01 -- Added support for additional planes.dat files
7/16/01 -- Capped line rendering distace to prevent bomber dropouts
8/19/01 -- Added planesLF.dat for low-fuel BoB 
10/2/01 -- Added 1.5 fuel burn rate mod
10/6/01 -- Fixed problem with fuel burn rate mod



 
