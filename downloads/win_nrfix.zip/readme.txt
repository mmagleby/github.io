Normal-Res Winter EAW Terrain Fix

These files will convert the Hi-Res Winter terrain to use Normal-Res Winter tiles.  It is intended to be used only if you are having problems using the Hi-Res tiles.  You MUST download and FULLY install the Hi-Res Winter Terrain (win_hr.zip) before using this fix. 



INSTRUCTIONS 

1) PREREQUISITE: You must download and install the Hi-Res Winter Terrain (win_hr.zip) FIRST.  MAKE SURE you run the make_bn.bat.  All of this is explained in the readme.txt included in win_hr.zip. 

2) Now let's move on to this patch.  Unzip the files to a directory.

3) Copy the files to your EAW directory.  It will overwrite the lr*.ter files you installed in step 1.

4) You're Done!  Run the game and enjoy the winter scenery!




max188
http://www.xmission.com/~mmagleby/eaw

Rev 1 - 4/27/01 - Normal-Res Winter EAW Terrain Fix
