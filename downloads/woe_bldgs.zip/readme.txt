Hi-res buildings for Wings Over Europe

These are hi-res buildings for use with Wings Over Europe. They replace the general city building and the outlying buildings in the game, adding more variety and detail. The shapes and locations of the buildings are not changed.



INSTRUCTIONS 

1) Back up any existing terobject_buildings1.bmp located in your ..\Wings Over Europe\Terrain\GermanyCE\directory (if applicable).

2) Copy the TEROBJECT_BUILDINGS1.bmp file in this zip file to the ..\Wings Over Europe\Terrain\GermanyCE directory.  Say yes if it asks to overwrite the existing file.

3) That's it, you're done.  Run the game and enjoy the buildings!



Notes:

1) If you want to go back to the default buildings, just delete the terobject_buildings1.bmp files from the GermanyCE directory.

2) Paint Shop Pro 8 was used to edit the tiles.


max188
http://www.xmission.com/~mmagleby/eaw

Rev 1.0 - 2/7/08 Hi-res buildings for Wings Over Europe
