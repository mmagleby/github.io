EAW Sky and Clouds

This add-on replaces the default sky and various cloud covers used in the game.  It includes a new sky, sun, horizon clouds, overcast clouds, and heavy clouds.  The horizon clouds will always appear.  Heavy clouds and overcast clouds will appear only when the game calls for them.

The horizon cloud textures are based on Bird's original clouds, the overcast cloud textures are converted from CFSII.



INSTRUCTIONS 

1) Unzip all the files to a directory.

2) Copy the *.ter and *.spt files to your EAW directory.  See note 3 if you only want to use specific parts of this add-on.



Notes:

1) If you use a terrain management program like STAB or Skins-n-More, you should copy the *.ter files  to the appropriate directory instead of the EAW directory.  Check the program's instructions on how to handle sky files.

2) Thanks and credit to Bird for his excellent horizon clouds.  Bird's original files are available at Cord's site.

3) The files are as follows:
BNCLOUD0 - Lower level clouds (grey, used only in heavy clouds scenario)
BNCLOUD1 - Overcast clouds (used only in overcast scenario)
BNCLOUD2 - Upper level clouds (white, used in partly cloudy and heavy clouds scenarios.  This add-on uses the game's default)
BNHORIZN - Horizon clouds
BNSKYBLU - Sky
HWSUN0-4 - Sun

You can use all or any combinations of these files as desired.
	

max188
http://www.xmission.com/~mmagleby/eaw

4/26/01 -- Winter EAW Horizon and Sky
6/3/01 -- EAW Overcast Sky
6/17/01 -- EAW Horizon Sky -- lightened sky color a bit to better fit both winter and summer.  Stretched clouds and resized to fix seam issue.
6/23/01 -- Modified to match better with horizon sky
11/11/01 -- EAW Sky and Clouds Added grey layer to heavy cloud conditions and packaged as single download
8/19/02 -- Added sun