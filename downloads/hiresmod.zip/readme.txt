Hi-Res EAW Terrain Utility

This very simple utility will rename EAW add-on terrain set files to use hi-res tiles.  EAW was built with 2 different resolutions of terrain tiles.  If you are using an add-on terrain, these tiles have been created as separate low-res and hi-res tile files.  The low-res tiles are 128x128 pixels and named lr*.ter.  The hi-res tiles are 256x256 pixels and named bn*.ter.  

It appears that EAW for some reason does not use the hi-res tiles, possibly a programming  oversite.  However, we can trick EAW into using them by renaming the hi-res tiles to the names of the low-res tiles.  This way, the game accesses the low-res tiles as normal, but gets the hi-res tiles instead.  The result is much better looking terrain, or more correctly, probably the way it was intended to look in the first place.  




INSTRUCTIONS 

1) Copy hiresmod.bat into the directory containing the add-on terrain set you wish to convert (see 
   note 1).

2) Double-click the hiresmod.bat file.

3) Copy the resulting *.ter files (including the originals) to your EAW directory.

4) You're Done!  Run the game and enjoy the higher resolution terrain tiles!



Notes:

1) You can run this directly in your EAW directory if the add-on terrain files are currently located there, and eliminate the #3 copying step.  However, I recommend converting the terrain in a separate directory if possible and then copying the files over to the EAW directory.

2) If you use a terrain management program like STAB or Skins-n-More, you should copy the resulting *.ter files  to the appropriate terrain directory instead of the EAW directory.

3) This utility also backs up the original low-res tiles as with a .bak extension.  You can change the extension back to .ter and copy them to your eaw directory if you need to return to the original terrain.  Otherwise, you may want to delete them to save space.

4) It is likely that the bn*.ter files are not actually necessary for the game to run properly.  However, my feeling is that it is best to leave them to be on the safe side.  If you are hurting for disk space, you may want to consider deleting them.

5) This should work with any add-on terrain set as they all use the same file format.

6) I have not found that the hi-res terrains cause any performance hit over the regular terrains in my testing, but its possible that with a low-end system or video card you may get some performance degradation.

7) If you would like to use the original EAW terrain but with hi-res tiles instead, you can download my Enhanced Hi-Res Original EAW Terrain set at http://www.neticus.com/users/mmagleby/eaw.  The original terrain looks very nice with the hi-res tiles, and you may want to revisit this "classic" eaw look.



max188
http://www.xmission.com/~mmagleby/eaw
3/12/01