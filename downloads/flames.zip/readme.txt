EAW Flame Enhancement

This optional file is intended to be used with the EAW Effects Pack.  If adds flames to damaged engines that are emitting black smoke.  There are also some unintentional side-effects listed in the notes section that you need to be aware of.



INSTRUCTIONS 

1) Unzip this package to a directory.

2) Copy the hwexplos.spt files to your EAW directory.


Notes:

1) You can revert to non-flaming effect by copying over the hwexplos.spt file from the EAW Effects Pack download.  Removing the file altogether will revert to the game's default fire effects.

2) This enhancement replaces any custom tracers you may be using from the EAW Effects Pack.

3) This enhancement works by switching some of the smoke graphics to fire graphics. The same smoke/fire graphics are used in other areas of the game as well.  One unfortunate result is that the train engine will also be spewing out fire as well!  Don't be alarmed, this is normal with this enhancement.  Fires burning on the ground will also have an extended column of fire.


max188
http://www.xmission.com/~mmagleby/eaw


7/12/02 -- Flame enhancement
8/23/02 -- texture update