//Desert Air War Icons
///////////////////////////////////////////

* icons by Mosi

These are some Desktop-Icons for the use with a dedicated EAW-installation for "Desert Air War", DAW for short. To use them, do the following:

1.) On your PC-Desktop, place the cursor on the EAW.exe shortcut and right click.

2.) LEFT CLICK on "Properties" and choose the "Change Icon" tab.

3.) Just open the folder where you unzipped the icons (EAw-folder recommended, but not necessary) and select the icon of choice for you.



---------------------------
Mosi, March 2002
http://mosi.thrustmaster.com