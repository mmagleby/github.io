//DAW Skinpack
//////////////

This file should list the origins of all skins appearing in the DAW-skinpack to give proper credit to all their creators.
A lot of these skins were enhanced and tweaked during the process of generating this skinpack, it was not possible to keep track with all enhancements which were included to all planes. To place the planes in their DAW-aircraft slots, Paulo Morais' utility SnapShot and hexediting have been used. 
Special thanks to Col. Gibbon for the help with the hardpoints and Moggy for his great work on several shadow-files.


** Credits
**********

Gladiator II (P51B slot) = skin and model by Woolfman
Huricane I (Tempest slot) = skin by Edward, model by Cpt. Kurt et al.
Hurricane IIB (Spit 9 slot) = skin by Mosi, model by Cpt. Kurt et al., cockpit by Migge
Hurricane IIC (Spit 14 slot) = skin by Mosi, model by Cpt. Kurt et al., cockpit by Migge
Spitfire V(Spit 2a slot) = model and skin by Flying Sheep
Tomahawk IIB (Typhoon slot) = skin by RedEyes et al., model by Cpt. Kurt 
Kittyhawk IA (Hurricane slot) = skin, model and cockpit by Flying Sheep
Martlet III (P47C slot) = skin by Emil, model by Cpt. Kurt
Beaufighter IC (P38H slot) = skin by vonOben, model by Woolfman
Beaufighter VIC (P38J slot) = skin by vonOben, model by Woolfman
Blenheim IV (B26 slot) = skin by C. Wilches, model by Cpt. Kurt
Wellington I (Mosquito slot) = skin and model by Woolfman et al.
Halifax B.II (B17 slot) = skin by -E and RedEyes, model by Moggy
Liberator II (B24 slot) = skin by -E
Marauder I (Me410 slot) = skin by C. Wilches

CR-42 (P47D slot) = skin and model by Woolfman
MC-200 (P51D slot) = skin by HarryM et al., model by Cpt. Kurt, cockpit by C. Wilches
MC-202 (190A slot) = skin by F. Mele, model by Cpt. Kurt, cockpit by C. Wilches

Bf 109E-7 (109E slot) = skin by Mosi, model by Cpt. Manduca
Bf 109F-2 (109K slot) = skin by Mosi, model by Cpt. Manduca et al., cockpit by Migge
Bf 109F-4 (109G slot) = skin by Mosi, model by Cpt. Manduca et al., cockpit by Migge
Bf 109G-2 (190D slot) = skin by Migge, model by Cpt. Manduca et al.
Bf 110C-4 (110C slot) = skin and model by Serb
Bf 110E-1 (110G slot) = skin by Migge et al.
Me 210A-1 (Me262 slot) = skin and model by Serb
Ju 88A-10 (88A slot) = skin by Steve O'Leary
He 111H-6 (111 slot) = skin by J. Hamilton
Ju 52/3m (88C slot) = skin by Mosi, model by Cord
Ju 87D-3 (87 slot) = skin by Mosi, model by Paulo Morais & GhostBoy

German Droptank = skin by Mosi, model by Cpt. Manduca


** Problems and Bugs
********************
- The cockpit of the Me 210A is created from pieces using different standard-cockpits. It was not possible due to the slot (262A) to add correct cockpit-gauches. As the 262a-slot does not support transparent propellors, the skin for the wingview is shared with the Bf 110C.

Note: This skinpack is far from being perfect!


------------------------------
Mosi, March 2002, for DAW
http://mosi.thrustmaster.com
