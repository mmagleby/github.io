Hi-Res Desert Air War Terrain

This is a hi-res terrain for the Desert Air War Campaign (DAW).  It it designed for use with the DAW custom terrain map, which splits the Mediterranean world into a European terrain area and a N. Africa terrain area.  These areas are modeled using half the available terrain tiles for each area.  As a result, there is less variation within each area, but the terrain characteristics are completely different depending on which half of the map you are in.  


INSTRUCTIONS 

1) Unzip all the files to a directory.

2) Double-click on the make_bn.bat file to create the cooresponding bn*.ter files.

3) Copy the *.ter files to your EAW directory.


Notes:

If you have trouble running hi-res terrains, a normal resolution patch is available.



max188
http://www.xmission.com/~mmagleby/eaw
Rev 1 - 1/20/02


