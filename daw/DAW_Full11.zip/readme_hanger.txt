  
*********************************************
* Hangar.zip readme.txt version 1.1 3/28/02 *  <- cool!
*********************************************


There hangar screens are intended to be used with Emil's Mediterranean Campaign.
Just unzip these files and the files from the sprites.zip file into the European Air War folder (or the equivalent if you are using Skins-N-More or another skin manager).

dancho